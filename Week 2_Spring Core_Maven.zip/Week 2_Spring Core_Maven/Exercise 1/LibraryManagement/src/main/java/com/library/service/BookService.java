package com.library.service;

public class BookService {
	public void bookServiceShow()
	{
		System.out.println("Inside BookService");
	}
}
